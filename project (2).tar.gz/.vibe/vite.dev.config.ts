import { defineConfig, mergeConfig } from 'vite'
import baseConfigExport from '../vite.config'
import { jsxLocPlugin } from '@builder.io/vite-plugin-jsx-loc'

export default defineConfig(async (env) => {
  const base = typeof baseConfigExport === 'function'
    ? await baseConfigExport(env)
    : baseConfigExport
  return mergeConfig(base, {
    plugins: [jsxLocPlugin()],
    server: { hmr: { overlay: false } },
  })
})
